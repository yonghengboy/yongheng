package demo.One;
import java.util.Scanner;//获取键盘 导包
public class Myscore {
    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);//创建键盘输入对象
        byte a = (byte) in.nextInt();//获取键盘输入
        //计算你自己某一学期期末总成绩平均分
        int sum=0;//总成绩
        int a2 ;//输入每门成绩
        double average = 0.0;
        int i =0;
        for (i=0;i<3;i++){
            System.out.println("请输入第"+(i+1)+"门的分数");
             sum += (byte) in.nextInt();//获取键盘输入
        }
        System.out.println("你的总成绩为"+sum);
    }
}
