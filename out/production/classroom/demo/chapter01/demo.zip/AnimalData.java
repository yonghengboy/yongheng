package demo.One;

public class AnimalData {
    public static void main(String[] args) {
//数据录入
        String number1 ="20230120";
        String class1 ="泰迪狗";
        String name1 = "lulu";
        char gender1 = '公';
        byte age1 = 5;
        String color1 = "棕色";
        String address1 ="昆明市五华区学府路恒泰花园小区";
        String  house1 ="2023-02-10";
        boolean healthy1 =true;

        String number2 ="20230212";
        String class2 ="本地猫";
        String name2 = "花花";
        char gender2 = '母';
        byte age2 = 2;
        String color2 = "麻花色";
        String address2 ="昆明市盘龙区立交桥";
        String  house2 ="2023-05-10";
        boolean healthy2 =false;

        //数据输出
        System.out.println("编号"+"/t/t"+"动物种类"+"/t");


      //  System.out.println(age1);
    }

}
